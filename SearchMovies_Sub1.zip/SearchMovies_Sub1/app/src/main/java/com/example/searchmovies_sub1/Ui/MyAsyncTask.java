package com.example.searchmovies_sub1.Ui;

import android.content.Context;
import android.support.v4.content.AsyncTaskLoader;
import android.text.TextUtils;

import com.example.searchmovies_sub1.MoviesItem;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.SyncHttpClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class MyAsyncTask extends AsyncTaskLoader<ArrayList<MoviesItem>> {
    private static final String API_KEY = "55b091c8e0360a45d6a546397d918c40";
    private ArrayList<MoviesItem> mData;
    private boolean mHasReslt = false;
    private String mDaftarMovies;

    public MyAsyncTask(final Context context, String mDaftarMovies) {
        super(context);
        onContentChanged();
        this.mDaftarMovies = mDaftarMovies;
    }

    @Override
    public ArrayList<MoviesItem> loadInBackground() {
        SyncHttpClient client = new SyncHttpClient();
        final ArrayList<MoviesItem> moviesItemses = new ArrayList<>();
        String url = "";
        if (!TextUtils.isEmpty(mDaftarMovies)){
            url = "https://api.themoviedb.org/3/search/movie?api_key="+API_KEY+"&language=en-US&query="+mDaftarMovies;
        } else {
            url = "https://api.themoviedb.org/3/discover/movie?api_key="+API_KEY;
        }


        client.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                setUseSynchronousMode(true);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                try {
                    String result = new String(responseBody);
                    JSONObject responseObject = new JSONObject(result);
                    JSONArray list = responseObject.getJSONArray("results");
                    for (int i = 0; i < list.length(); i++) {
                        JSONObject resultDetail = list.getJSONObject(i);
                        MoviesItem moviesItems = new MoviesItem(resultDetail);
                        moviesItemses.add(moviesItems);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
        return moviesItemses;
    }

    @Override
    public void deliverResult(final ArrayList<MoviesItem> data) {
        mHasReslt = true;
        mData = data;
        super.deliverResult(data);
    }

    @Override
    protected void onStartLoading() {
        if (takeContentChanged())
            forceLoad();
        else if (mHasReslt)
            deliverResult(mData);
    }


    @Override
    protected void onReset() {
        super.onReset();
        onStopLoading();
        if (mHasReslt) {
            onRealeaseResources(mData);
            mData = null;
            mHasReslt = false;
        }
    }
    private void onRealeaseResources(ArrayList<MoviesItem> mData) {

    }
}
