package com.example.searchmovies_sub1;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;

import com.example.searchmovies_sub1.Adapter.MoviesAdapter;
import com.example.searchmovies_sub1.Ui.DetailsMovies;
import com.example.searchmovies_sub1.Ui.MyAsyncTask;

import java.util.ArrayList;
import java.util.List;

import static com.loopj.android.http.AsyncHttpClient.log;

public class MainActivity extends AppCompatActivity implements View.OnClickListener,
        LoaderManager.LoaderCallbacks<ArrayList<MoviesItem>>, AdapterView.OnItemClickListener {
    static final String Extras_Movies = "Extras_Movies";
    ListView ListMovies;
    MoviesAdapter mAdapter;
    EditText txtCari;
    Button btnCariMovies;
    private RelativeLayout LyItemMovies;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAdapter = new MoviesAdapter(this);
        mAdapter.notifyDataSetChanged();
        ListMovies = findViewById(R.id.ListMovies);
        ListMovies.setAdapter(mAdapter);
        LyItemMovies = findViewById(R.id.LyItemMovies);
        ListMovies.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MoviesItem m = (MoviesItem) parent.getItemAtPosition(position);
                log.d("senddata", m.toString());
                Intent intent = new Intent(MainActivity.this, DetailsMovies.class);
                intent.putExtra("senddata2", m);
                startActivity(intent);
            }
        });
        txtCari = findViewById(R.id.txt_cari);
        btnCariMovies = findViewById(R.id.btn_carimovies);
        btnCariMovies.setOnClickListener(this);
        String title = txtCari.getText().toString();
        Bundle bundle = new Bundle();
        bundle.putString(Extras_Movies, title);
        getSupportLoaderManager().initLoader(0, bundle, this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_carimovies:
                String judulMovies = txtCari.getText().toString();
                if (TextUtils.isEmpty(judulMovies)) return;
                Bundle bundle = new Bundle();
                bundle.putString(Extras_Movies, judulMovies);
                getSupportLoaderManager().restartLoader(0, bundle, MainActivity.this);
                break;
            case R.id.LyItemMovies:

                break;
        }

    }

    @Override
    public Loader<ArrayList<MoviesItem>> onCreateLoader(int id, Bundle args) {
        String title = "";

        if (args != null) {
            title = args.getString(Extras_Movies);
        }
        return new MyAsyncTask(this, title);
    }


    @Override
    public void onLoadFinished(@NonNull Loader<ArrayList<MoviesItem>> loader, ArrayList<MoviesItem> data) {
        mAdapter.setData(null);
        mAdapter.setData(data);
    }

    @Override
    public void onLoaderReset(Loader<ArrayList<MoviesItem>> loader) {
        mAdapter.setData(null);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        MoviesItem m = (MoviesItem) parent.getItemAtPosition(position);
        log.d("senddata", m.toString());
        Intent intent = new Intent(MainActivity.this, DetailsMovies.class);
        intent.putExtra(Extras_Movies, m);
        startActivity(intent);
    }
}
