package com.example.searchmovies_sub1.Adapter;

import android.content.Context;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v4.widget.ViewDragHelper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.searchmovies_sub1.MoviesItem;
import com.example.searchmovies_sub1.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MoviesAdapter extends BaseAdapter {
    private ArrayList<MoviesItem> mDat = new ArrayList<>();
    private LayoutInflater mInflat;
    private Context context;

    private static class ViewHolder {
        TextView textViewTitle;
        TextView textViewOverview;
        TextView textViewRealese;
        ImageView imageViewPoster;
    }

    public MoviesAdapter(Context context) {
        this.context = context;
        mInflat = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public void addItem(final MoviesItem item) {
        mDat.add(item);
        notifyDataSetChanged();
    }

    public void clearData() {
        mDat.clear();
    }

    @Override
    public int getCount() {
        if (mDat == null) return 0;
        return mDat.size();
    }

    @Override
    public MoviesItem getItem(int position) {
        return mDat.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflat.inflate(R.layout.item_movies, null);
            holder.textViewTitle = (TextView) convertView.findViewById(R.id.txt_name);
            holder.textViewOverview = (TextView) convertView.findViewById(R.id.txt_overview);
            holder.textViewRealese = (TextView) convertView.findViewById(R.id.txt_realeas);
            holder.imageViewPoster = (ImageView) convertView.findViewById(R.id.ImPoster);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.textViewTitle.setText(mDat.get(position).getTitle());
        String detail = mDat.get(position).getOverview().substring(0,50);
        holder.textViewOverview.setText(detail+"...");
        String reales = mDat.get(position).getRealease();
        holder.textViewRealese.setText("Release : "+reales);
        Uri url_image = Uri.parse("http://image.tmdb.org/t/p/w185" +mDat.get(position).getPoster());
        Picasso
                .with(context)
                .load(url_image)
                .into(holder.imageViewPoster);
        return convertView;
    }

    public void setData(ArrayList<MoviesItem> data) {
        mDat = data;
        notifyDataSetChanged();
    }
}
